
def tokenize(input_phrase):
    return input_phrase.split(" ")